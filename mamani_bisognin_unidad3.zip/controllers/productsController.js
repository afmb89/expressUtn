const productsModel = require("../models/productsModel");

module.exports = {
    getAll:async function(req, res, next) {
        try{
            const productos = await productsModel.find();
            res.json(productos);
        }catch(e){
            next(e);
        }        
    },
    getById: async function(req, res, next) {
        try{
            const productos = await productsModel.findById(req.params.id);
            res.json(productos);
        }catch(e){
            next(e);
        }        
    },
    create: async function(req, res, next){        
        try{
            const producto = new productsModel({
                name:req.body.name,
                sku:req.body.sku,
                description:req.body.description,
                price:req.body.price,
                img:req.body.img
            });
            const prod = await producto.save();
            const productos = await productsModel.find();
            res.json(productos);
        }catch(e){
            /*console.log(e.name);*/
            next(e.name);
        }
    },
    update: async function(req, res, next){
        try{
            let producto = await productsModel.updateOne({_id:req.params.id}, req.body, {multi:false});
            const productos = await productsModel.find();
            res.json(productos);
        }catch(e){
            next(e);
        }
    },
    delete: async function(req, res, next){
        try{
            let producto = await productsModel.deleteOne({_id:req.params.id});
            const productos = await productsModel.find();
            res.json(productos);
        }catch(e){
            next(e);
        }
    }
}